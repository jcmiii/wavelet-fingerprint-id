function y = HWT1D1()
%Haar returns the Haar filter

y=sqrt(2)*[1;1]/2;